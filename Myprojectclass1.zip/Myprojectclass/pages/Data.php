<?php 
    include "koneksi.php";
    include "resources/reader/excel_reader2.php";
?>
<div class="row" style="margin-top:10px;">

    <h4>PENGOLAHAN DATA</h4>
    <p>Data</p>
    <div class="col s3">
        <form action="" method="post" enctype="multipart/form-data">
           <div class="file-field input-field">
              <div class="btn blue-grey darken-4">
                <span>File xlsx</span>
                <input type="file" name="Ifile" id="" class="" />
              </div>
              <div class="file-path-wrapper">
                  <input class="file-path validate" type="text">
              </div>
            </div>
    </div>
    <div class="col s4">
      <br>
    <button class="btn blue-grey darken-3" name="upload" type="submit"><i class="material-icons left">cloud</i>Upload</button>
    </form>
    </div>
    <div class="col s4">
        <!-- Modal Trigger -->
        <form method="POST">
        <button type="Submit" name="bersih" class="btn-floating tooltipped btn-large waves-effect waves-light red right" data-position="bottom" data-tooltip="Hapus Seluruh Data"><i class="material-icons">delete_forever</i></button>
        </form>
        <a style="margin-right:10px;" class="btn-floating tooltipped btn-large waves-effect modal-trigger blue-grey darken-4 right" href="#modal1" data-position="left" data-tooltip="Tambah Data Secara Manual"><i class="material-icons">add</i></a>
      
        <!-- Modal Structure Tambah Manual -->
        <div id="modal1" class="modal modal-fixed-footer">
          <div class="modal-content">
            <h4>Input Data Manual</h4>
            <p>Input Data Secara Manual</p>
            <form method="post">
                  <div class="input-field col s12">
                    <input type="text" name="Ikota" id="Kota" class="validate">
                    <label for="Kota">Provinsi</label>
                  </div>
                  <div class="input-field col s12">
                    <input type="number" name="Isiswa" id="siswa" class="validate">
                    <label for="Siswa">Data Tahun 2015</label>
                  </div>
                  <div class="input-field col s12">
                    <input type="number" name="Isekolah" id="sekolah" class="validate">
                    <label for="Sekolah" data-error="wrong" data-success="right">Data Tahun 2016</label>
                  </div>
                  
                  <div class="input-field col s12">
                    <input type="number" name="Iti" id="sekolah" class="validate">
                    <label for="TI" data-error="wrong" data-success="right">Data Tahun 2017</label>
                  </div>
                  
                  <div class="input-field col s12">
                    <input type="text" name="Itahun" id="sekolah" class="validate">
                    <label for="Tahun" data-error="wrong" data-success="right">Data Tahun 2018</label>
                  </div> 
                  <div class="input-field col s12">
                    <input type="text" name="Itahun" id="sekolah" class="validate">
                    <label for="Tahun" data-error="wrong" data-success="right">Data Tahun 2019</label>
                  </div>      
          </div>
          <div class="modal-footer">
            <button type="submit" name="kirim" class="btn waves-effect teal">Tambah Data</button>
            </form>
          </div>
        </div>
        </div>
    </div>

   <div class="row">
    <div class="col s12 m8 l11">
    <table class="responsive-table" id="tab">
        <thead class="blue-grey darken-4 white-text">
            <tr>
             <th class="center">No</th>
              <th class="center">Provinsi</th>
              <th class="center">2015</th>
              <th class="center">2016</th>
              <th class="center">2017</th>
              <th class="center">2018</th>
              <th class="center">2019</th>
              <th class="center">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
          $sql = "SELECT * From tb_data";
          $t = mysqli_query($conn,$sql);
          $no = 1;
          while ($data = mysqli_fetch_array($t)) {
        ?>
            <tr class="center">
                <td><?= $no ?></td>
                <td><?= $data['Provinsi'] ?></td>
                <td><?= $data['2015'] ?></td>
                <td><?= $data['2016'] ?></td>
                <td><?= $data['2017'] ?></td>
                <td><?= $data['2018'] ?></td>
                <td><?= $data['2019'] ?></td>
                <td><a href="#hapus<?= $Data['ID_Data'] ?>" class="waves-effect waves-light btn modal-trigger red"><i class="material-icons">delete</i></a>
                    &nbsp <a href="#edit<?= $Data['ID_Data'] ?>" class="waves-effect waves-light btn modal-trigger yellow"><i class="material-icons">edit</i></a>
              </td>
            </tr>

            <!-- Modal Hapus -->
            <div id="hapus<?= $Data['ID_Data'] ?>" class="modal bottom-sheet">
              <div class="modal-content">
                <h4>Konfirmasi Hapus Data</h4>
                <p>Apakah anda yakin ingin menghapus Data dari Kota <?= $Data['Kota'] ?> di Tahun <?= $Data['Tahun'] ?> ? </p>
              </div>
              <div class="modal-footer">
                <form method="POST">
                <input type="hidden" name="Ikode" value="<?= $Data['ID_Data'] ?>">
                <button type="submit" name="hapus" class=" modal-action modal-close waves-effect waves-light red btn"><i class="material-icons">delete</i></button>
                </form>
                <a href="#!" class=" modal-action modal-close waves-effect green btn ">Tidak Jadi</a>
              </div>
            </div>
            
            <!-- Modal Structure -->
        <div id="edit<?= $Data['ID_Data'] ?>" class="modal modal-fixed-footer">
          <div class="modal-content">
            <h4>Halaman Edit Data</h4>
            <p>Edit Data Pada Kota :</p>
            <form method="post">
            <div class="input-field col s12">
                    <input type="text" name="Ikota" id="Kota" class="validate">
                    <label for="Kota">Provinsi</label>
                  </div>
                  <div class="input-field col s12">
                    <input type="number" name="Isiswa" id="siswa" class="validate">
                    <label for="Siswa">Data Tahun 2015</label>
                  </div>
                  <div class="input-field col s12">
                    <input type="number" name="Isekolah" id="sekolah" class="validate">
                    <label for="Sekolah" data-error="wrong" data-success="right">Data Tahun 2016</label>
                  </div>
                  
                  <div class="input-field col s12">
                    <input type="number" name="Iti" id="sekolah" class="validate">
                    <label for="TI" data-error="wrong" data-success="right">Data Tahun 2017</label>
                  </div>
                  
                  <div class="input-field col s12">
                    <input type="text" name="Itahun" id="sekolah" class="validate">
                    <label for="Tahun" data-error="wrong" data-success="right">Data Tahun 2018</label>
                  </div> 
                  <div class="input-field col s12">
                    <input type="text" name="Itahun" id="sekolah" class="validate">
                    <label for="Tahun" data-error="wrong" data-success="right">Data Tahun 2019</label>
                  </div>  
          </div>
          <div class="fixed-action-btn">
            <input type="hidden" name="Ekode" value="<?= $Data['ID_Data'] ?>">
            <button type="submit" name="edit" class="btn btn-floating btn-large waves-effect orange"><i class ="material-icons">edit</i></button>
            </form>
          </div>
          </div>

        <?php
          $no++;
          }
        ?>
        </tbody>
    </table>

    </div>
   </div>

<?php
    if (isset($_POST['kirim'])) {
        $tahun = $_POST['Itahun'];
        $kota = $_POST['Ikota'];
        $siswa = $_POST['Isiswa'];
        $sekolah = $_POST['Isekolah'];
        $ti = $_POST['Iti'];
        $dkv = $_POST['Idkv'];
        $pbm = $_POST['Ipbm'];
        $ak = $_POST['Iak'];
        
        $sql = "insert into tb_data(Kota,Siswa,Sekolah,TI,DKV,PBM,Akuntansi,Tahun) 
        values('$kota','$siswa','$sekolah','$ti','$dkv','$pbm','$ak','$tahun')";
        $try = mysqli_query($conn,$sql);
        if ($try) { 
        echo "<script> M.toast({html: '<i class=material-icons>done</i> Data $kota Tahun $tahun Telah Terinput', classes:'rounded green'}) </script>";
        ?>
        <script> setTimeout("location.href = '?p=data';" ,1500); </script>
      <?php
      }
    }

    if (isset($_POST['upload'])) {
      $files = "resources/assets/".basename($_FILES['Ifile']['name']);
      move_uploaded_file($_FILES['Ifile']['tmp_name'],$files);

      chmod("resources/assets/".$_FILES['Ifile']['name'],0777);
      $data = new Spreadsheet_Excel_Reader($files);
      $baris = $data->rowcount($sheet_index = 0);
      
      //cek berapa baris
      // print_r($baris);

      for ($i=2; $i <= $baris; $i++) { 
        $kota = $Data->val($i, 1);
        $siswa = $Data->val($i, 2);
        $sekolah = $Data->val($i, 3);
        $ti = $Data->val($i, 4);
        $dkv = $Data->val($i, 5); 
        $pbm = $Data->val($i, 6); 
        $ak = $Data->val($i, 7);
        $tahun = $Data->val($i, 8);

        $sql = "insert into tb_data(Kota,Siswa,Sekolah,TI,DKV,PBM,Akuntansi,Tahun) 
        values('$kota','$siswa','$sekolah','$ti','$dkv','$pbm','$ak','$tahun')";
        $try = mysqli_query($conn,$sql);
        if ($try) { }
      }
      echo" <script> M.toast({html: '<i class=material-icons>done_all</i> File Telah Terupload', classes:'rounded green'}) </script>";
      ?> <script> setTimeout("location.href = '?p=data';" ,1500); </script>
    <?php
    }

    if (isset($_POST['edit'])) {
      $tahun = $_POST['Etahun'];
      $kota = $_POST['Ekota'];
      $siswa = $_POST['Esiswa'];
      $sekolah = $_POST['Esekolah'];
      $ti = $_POST['Eti'];
      $dkv = $_POST['Edkv'];
      $pbm = $_POST['Epbm'];
      $ak = $_POST['Eak'];
      $kode = $_POST['Ekode'];

      $sql = "UPDATE tb_data SET Kota = '$kota', Siswa = '$siswa', Sekolah = '$sekolah', TI = '$ti'
      , DKV = '$dkv', PBM = '$pbm', Akuntansi = '$ak', Tahun = '$tahun' where ID_Data = '$kode' ";
      $c = mysqli_query($conn,$sql);

      if($c) {
        echo "<script> M.toast({html: '<i class=material-icons>done</i> Data $kota Tahun $tahun Berhasil Dirubah', classes:'rounded green'}) </script>";
        ?>
        <script> setTimeout("location.href = '?p=data';" ,1500); </script>
      <?php
      }else{
        echo "<script> M.toast({html: '<i class=material-icons>done</i> Data $kota Tahun $tahun Gagal Dirubah', classes:'rounded red'}) </script>";
      }

    }

    if (isset($_POST['hapus'])) {
      $kode = $_POST['Ikode'];
      $sql = "DELETE FROM tb_data Where ID_Data = '$kode' ";
      $h = mysqli_query($conn,$sql);

      if($h) {
        echo "<script> M.toast({html: '<i class=material-icons>done</i> Data Berhasil Dihapus', classes:'rounded green'}) </script>";
        ?>
        <script> setTimeout("location.href = '?p=data';" ,1500); </script>
      <?php
      }else{
        echo "<script> M.toast({html: '<i class=material-icons>done</i> Data Gagal Dihapus', classes:'rounded red'}) </script>";
      }
    }

    if (isset($_POST['bersih'])) {
      
      $sql ="TRUNCATE tb_data";
      $be = mysqli_query($conn,$sql);

      if ($be) {
        echo "<script> M.toast({html: '<i class=material-icons>done</i> Seluruh File Dihapus', classes:'rounded red'}) </script>";
      }

    }

?>

<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<script>
  $(document).ready(function(){
    $('.modal').modal();
    $('.tooltipped').tooltip();
    $('#tab').DataTable();
  });
</script>