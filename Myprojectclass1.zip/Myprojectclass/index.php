<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    if (empty($_GET['p'])) {
        $_GET['p'] = "Home";
    }
    ?>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= "".$_GET['p']; ?></title>
    <link rel="stylesheet" href="css/materialize.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="js/chart/Chart.min.css">

    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
    <script src="js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="js/materialize.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
</head>
<body>

    <!-- Navbar -->
    <!-- <header id="header" class="page-topbar">
    <nav>
        <div class="nav-wrapper blue-grey darken-4">
        <ul class="right">
        <li><a class='dropdown-trigger tooltipped' href='#' data-position="left" data-tooltip="Control Panel" data-target='pilihmenu'><i class="material-icons">settings</i></a></li>
        </ul>

        <ul id='pilihmenu' class='dropdown-content blue darken-4'>
        <li><a class="white-text" href="#"><i class="white-text material-icons">lock</i>Logout</a></li>
        <li><a class="white-text" href="#"><i class="white-text material-icons">info</i>Something Else ?</a></li>
        </ul>
        </div>
    </nav>
    </header> -->

    <!-- Content -->
    <div id="main">
    <div class="row">
    <div class="col s12 m4 l3">
    <ul class="sidenav sidenav-collapsible leftside-navigation sidenav-fixed blue-grey darken-4" id="mobile-menu">
        <li> 
            <div class="user-view">
                <a href="?p=Home"><img src="images/ClusterWebApp.png" width="80" height="80"></a>
                <span class="white-text name" style="padding-top: 0cm;">Clustering Penyakit Malaria Di Indonesia</span> <hr>
                <span class="white-text email" style="padding-bottom: 2cm;">Jl. Soekarno - Hatta, Kota Malang, Jawa Timur 65113</span>
            </div>
        </li>
        <li><a class="white-text" href="?p=Data">MENEJEMEN DATA</a></li>
        <li><a class="white-text" href="?p=Perhitungan C3" style="line-height: 0.1cm;">PERHITUNGAN</a></li>
        <li><a class="white-text" href="?p=Hasil C3">HASIL DATA</a></li>
    </ul>
    </div>
    <div class="col s12 m12 l9">
       
           <?php
                $p_dir ="pages";
                if (!empty($_GET['p'])) {
                    $pages = scandir($p_dir, 0);
                    unset($pages[0], $pages[1]);
        
                    $p = $_GET['p'];
                    if (in_array($p.'.php', $pages)) {
                        include($p_dir.'/'.$p.'.php');
                    } else{
                        ?>
                        <div class="nodim">
                        <h2>ERROR 404</h2>
                        <h4>Laman Kamu Cari Masih Belum Tersedia :'((</h4>
                        </div>
                        <?php
                    }
                } else {
                    include($p_dir.'/Home.php');
                }
           ?>
        </div>
        </div>
        </div>
    </div>
</body>


<footer>
    <div style="padding-top: 5.9cm;">
        <div class="row">
            <div class="right">
                <h5 class="black-text" style="text-align:right;"> <b style="color: grey;"> Project Tugas Akhir &nbsp&nbsp</h5> 
                <p class="black-text text-lighten-4" style="text-align:right;  line-height: 0.2cm;"> <b style="color: grey;">Clustering Penyakit Malaria di Indonesia Menggunakan Algoritma K-Means &nbsp&nbsp&nbsp&nbsp</p>
                <a class="black-text text-lighten-4 right" href="#!" style="text-align:right; line-height: 0.1cm;" > <b style="color: grey;"> © <?= date("Y") ?> <b style="color: grey;"> lastassignment campus &nbsp&nbsp&nbsp&nbsp</a>
            </div>
        </div>
    </div>
</footer>

<!-- script -->
<script>
  $(document).ready(function(){
    $('.sidenav').sidenav();
    $('.tooltipped').tooltip();
    $('.dropdown-trigger').dropdown();
  });
</script>
</html>